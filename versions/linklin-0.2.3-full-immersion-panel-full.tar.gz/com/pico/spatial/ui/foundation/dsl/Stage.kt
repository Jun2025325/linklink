/*
 * Copyright 2024 - 2026 PICO. All rights reserved.
 *
 * NOTICE: All information contained herein is, and remains the property of PICO.
 * The intellectual and technical concepts contained herein are proprietary to PICO
 * and may be covered by patents, patents in process, and are protected by trade
 * secret or copyright law. Dissemination of this information or reproduction of
 * this material is strictly forbidden unless prior written permission is obtained
 * from PICO.
 */

@file:Suppress("INVISIBLE_MEMBER", "INVISIBLE_REFERENCE")

package com.pico.spatial.ui.foundation.dsl

import androidx.activity.ComponentActivity
import androidx.annotation.IntRange
import androidx.compose.runtime.Composable
import com.pico.spatial.core.container.Stage
import com.pico.spatial.core.container.StageProperties
import com.pico.spatial.ui.foundation.content.SpatialView
import com.pico.spatial.ui.platform.ability.UpperLimbRenderMode
import com.pico.spatial.ui.platform.ability.convertToPackType
import com.pico.spatial.ui.platform.containers.SUISpatialContainerManager
import com.pico.spatial.ui.platform.containers.StageScope
import com.pico.spatial.ui.platform.containers.StageStyle
import com.pico.spatial.ui.platform.containers.openStage
import com.pico.spatial.ui.platform.containers.toPackType
import com.pico.spatial.ui.platform.stub.SpatialLaunchActivity

/**
 * The first [Stage] of app, started by PICO OS. Currently must be configured at app's
 * AndroidManifest.xml.
 *
 * The first [WindowContainer] of app, started by PICO OS. Currently must be configured at app's
 * AndroidManifest.xml.
 *
 * Your launch activity should extend [SpatialLaunchActivity].
 *
 * ```xml
 * <application>
 *        <activity
 *             android:name=".platform.LaunchActivity"
 *             android:exported="true"
 *             android:theme="@style/Theme.SpatialApp">
 *             <intent-filter>
 *                 <action android:name="android.intent.action.MAIN" />
 *                 <category android:name="android.intent.category.LAUNCHER" />
 *             </intent-filter>
 *
 *             <meta-data android:name="pico.spatial.stage.id" android:value="MainStage"/>
 *             <meta-data android:name="pico.spatial.stage.style" android:value="0"/>
 *             <meta-data android:name="pico.spatial.stage.immersion" android:value="50"/>
 *             <meta-data android:name="pico.spatial.stage.immersion_min" android:value="0"/>
 *             <meta-data android:name="pico.spatial.stage.immersion_max" android:value="100"/>
 *         </activity>
 * </application>
 * ```
 *
 * It needs to be configured in AndroidManifest, like [DefaultWindowContainer]. The app entrance can
 * be either [DefaultStage] or [DefaultWindowContainer].
 *
 * @see Stage
 */
// PICO OS Metadata spec (internal reference)
@Suppress("FunctionNaming")
fun SpatialAppScope.DefaultStage(content: @Composable StageScope.() -> Unit) {
    SUISpatialContainerManager.registerDefaultStage(content)
}

/**
 * Declares a Stage with unique [id]. The [id] is used to execute open/close operations.
 *
 * Stage is a boundless container provided by PICO OS.
 *
 * When Stage is opened, the system will hide windows from other apps.
 *
 * @param id The unique id of Stage.
 * @param immersion The immersion of the Stage when it's opened. Only takes effect when
 *   [openStage]'s style is [StageStyle.Progressive], the default is [DefaultImmersionLevel], the
 *   range in [MinImmersionLevel]..[MaxImmersionLevel].
 * @param brightness The [Brightness] to apply for this [Stage]. It cannot be changed while the
 *   Stage is alive.
 * @param upperLimbRenderMode The upperLimbRenderMode of Stage.
 * @param targetActivity The activity that bind to this [Stage].
 * @param content A [Composable] describe the content of Stage, typically use a [SpatialView] to
 *   present 3D content.
 */
@Suppress("FunctionNaming")
fun SpatialAppScope.Stage(
    id: String,
    immersion: Immersion? = null,
    brightness: Brightness? = null,
    upperLimbRenderMode: UpperLimbRenderMode? = null,
    targetActivity: Class<out ComponentActivity>? = null,
    content: @Composable StageScope.() -> Unit,
) {
    val props =
        StageProperties(
            name = id,
            imm = immersion?.toPackType(),
            brightness = brightness?.value,
            // style will be replaced by openStage
            style = StageStyle.Automatic?.toPackType(),
            upperLimbRenderMode = upperLimbRenderMode?.convertToPackType(),
            activityClass = targetActivity,
        )
    SUISpatialContainerManager.registerStageContent(props, content)
}

/** The default immersion level of [Stage]'s progressive. */
private const val DefaultImmersionLevel = 50
/** The min immersion level of [Stage]'s progressive. */
private const val MinImmersionLevel = 0
/** The max immersion level of [Stage]'s progressive. */
private const val MaxImmersionLevel = 100

/**
 * The range of [Stage]'s immersion.
 *
 * @param default The default level of [Stage]'s progressive in 0...100.
 * @param min The min level of [Stage]'s progressive in 0...100 default is 0.
 * @param max The max level of [Stage]'s progressive in 0...100 default is 100.
 * @return The [Immersion]
 */
fun Immersion(
    @IntRange(from = 0, to = 100) default: Int,
    @IntRange(from = 0, to = 100) min: Int = 0,
    @IntRange(from = 0, to = 100) max: Int = 100,
): Immersion {
    return Immersion(defaultValue = default, minValue = min, maxValue = max)
}

/**
 * The range of [Stage]'s immersion.
 *
 * @param defaultValue The default level of [Stage]'s progressive in 0...100.
 * @param minValue The min level of [Stage]'s progressive in 0...100.
 * @param maxValue The max level of [Stage]'s progressive in 0...100.
 */
class Immersion
internal constructor(
    val defaultValue: Int,
    val minValue: Int,
    val maxValue: Int,
    private val defaultRange: kotlin.ranges.IntRange = MinImmersionLevel..MaxImmersionLevel,
) {
    /** validMin, the min level of [Stage]'s progressive In 0...100. */
    val validMinValue: Int
        get() = if (minValue in defaultRange) minValue else MinImmersionLevel

    /**
     * validMax, more than the [validMinValue],the max level of [Stage]'s progressive In 0...100.
     */
    val validMaxValue: Int
        get() =
            if (maxValue in defaultRange) maxValue.coerceAtLeast(validMinValue)
            else MaxImmersionLevel

    /**
     * validDefaultLevel, the default level of [Stage]'s progressive between [validMinValue] and
     * [validMaxValue].
     */
    val validDefaultValue: Int
        get() = defaultValue.coerceIn(validMinValue..validMaxValue)

    /**
     * The companion of [Immersion].
     *
     * It provides a default range of [Stage]'s immersion.
     */
    companion object {
        /** The default range of [Stage]'s immersion. */
        val Default = Immersion(DefaultImmersionLevel, MinImmersionLevel, MaxImmersionLevel)
    }
}

private fun Immersion.toPackType() =
    com.pico.spatial.core.container.Immersion(
        default = validDefaultValue,
        min = validMinValue,
        max = validMaxValue,
    )
