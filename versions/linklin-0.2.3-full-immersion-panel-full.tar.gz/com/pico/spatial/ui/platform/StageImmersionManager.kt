/*
 * Copyright 2025 - 2026 PICO. All rights reserved.
 *
 * NOTICE: All information contained herein is, and remains the property of PICO.
 * The intellectual and technical concepts contained herein are proprietary to PICO
 * and may be covered by patents, patents in process, and are protected by trade
 * secret or copyright law. Dissemination of this information or reproduction of
 * this material is strictly forbidden unless prior written permission is obtained
 * from PICO.
 */

@file:Suppress("INVISIBLE_MEMBER", "INVISIBLE_REFERENCE")

package com.pico.spatial.ui.platform

import androidx.compose.runtime.IntState
import androidx.compose.runtime.MutableIntState
import androidx.compose.runtime.mutableIntStateOf
import com.pico.spatial.core.container.SpatialContainerManager
import com.pico.spatial.core.container.SpatialImmersionListener

/**
 * The [StageImmersionManager] is responsible for providing and listening to the immersion level of
 * a progressive Stage.
 */
interface StageImmersionManager {
    /** The current immersion level of the Stage. */
    val currentImmersionLevel: IntState
    /** The minimum immersion level of the Stage. */
    val immersionMinLevel: Int
    /** The maximum immersion level of the Stage. */
    val immersionMaxLevel: Int

    /**
     * Adds a [StageImmersionListener] to the [StageImmersionManager].
     *
     * @param listener The [StageImmersionListener] to add.
     */
    fun addImmersionListener(listener: StageImmersionListener)

    /**
     * Removes a [StageImmersionListener] from the [StageImmersionManager].
     *
     * @param listener The [StageImmersionListener] to remove.
     */
    fun removeImmersionListener(listener: StageImmersionListener)
}

/**
 * The [StageImmersionListener] listens to the immersion level of a progressive [Stage].
 *
 * @see StageImmersionManager
 */
interface StageImmersionListener {
    /**
     * Called when the immersion level of the Stage is changed.
     *
     * @param immersionLevel The new immersion level of the Stage.
     */
    fun onImmersionChanged(immersionLevel: Int)
}

internal object StageImmersionManagerImpl : StageImmersionManager, SpatialImmersionListener {
    private val listeners: MutableList<StageImmersionListener> = mutableListOf()
    private var _mutableLevel: MutableIntState = mutableIntStateOf(0)
    private var _minImmersionLevel = 0
    private var _maxImmersionLevel = 0

    override val currentImmersionLevel: IntState
        get() = _mutableLevel

    override val immersionMinLevel: Int
        get() = _minImmersionLevel

    override val immersionMaxLevel: Int
        get() = _maxImmersionLevel

    private val defaultImmersionRange = 0..100

    fun updateStageImmersion(immersionLevel: Int, minImmersionLevel: Int, maxImmersionLevel: Int) {
        val validMinLevel =
            if (minImmersionLevel in defaultImmersionRange) minImmersionLevel
            else defaultImmersionRange.first
        var validMaxLevel =
            if (maxImmersionLevel in defaultImmersionRange) maxImmersionLevel
            else defaultImmersionRange.last
        validMaxLevel = validMaxLevel.coerceAtLeast(validMinLevel)
        val validLevel = immersionLevel.coerceIn(validMinLevel, validMaxLevel)

        _minImmersionLevel = validMinLevel
        _maxImmersionLevel = validMaxLevel
        _mutableLevel.intValue = validLevel
    }

    override fun addImmersionListener(listener: StageImmersionListener) {
        listeners.add(listener)
    }

    override fun removeImmersionListener(listener: StageImmersionListener) {
        if (listeners.isEmpty()) return
        listeners.remove(listener)
    }

    override fun onStageImmersionChanged(containerId: Int, immersion: Int) {
        if (listeners.isEmpty()) return
        val validImmersionLevel = immersion.coerceIn(immersionMinLevel, immersionMaxLevel)
        _mutableLevel.intValue = validImmersionLevel
        listeners.forEach { it.onImmersionChanged(validImmersionLevel) }
    }

    internal fun registerContainerManagerListener() {
        SpatialContainerManager.registerStageImmersionListener(this)
    }

    internal fun unregisterContainerManagerListener() {
        SpatialContainerManager.unregisterStageImmersionListener(this)
    }
}
