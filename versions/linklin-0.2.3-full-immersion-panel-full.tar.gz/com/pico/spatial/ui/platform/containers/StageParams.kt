/*
 * Copyright 2026 PICO. All rights reserved.
 *
 * NOTICE: All information contained herein is, and remains the property of PICO.
 * The intellectual and technical concepts contained herein are proprietary to PICO
 * and may be covered by patents, patents in process, and are protected by trade
 * secret or copyright law. Dissemination of this information or reproduction of
 * this material is strictly forbidden unless prior written permission is obtained
 * from PICO.
 */

package com.pico.spatial.ui.platform.containers

import androidx.annotation.VisibleForTesting
import com.pico.spatial.core.container.SpatialContainer
import com.pico.spatial.core.container.Stage

/** [Stage]'s styles. */
enum class StageStyle {
    /** Style is determined by the OS. */
    Automatic,

    /** Mixed your virtual content with video passthrough. */
    Mixed,

    /** User can adjust immersion ratio from 0% to 100%. */
    Progressive,

    /** App takeover all display, video passthrough will be turned off. */
    Full,
}

@VisibleForTesting
internal fun StageStyle.toPackType() =
    when (this) {
        StageStyle.Automatic -> com.pico.spatial.core.container.StageStyle.AUTOMATIC
        StageStyle.Mixed -> com.pico.spatial.core.container.StageStyle.MIXED
        StageStyle.Progressive -> com.pico.spatial.core.container.StageStyle.PROGRESSIVE
        StageStyle.Full -> com.pico.spatial.core.container.StageStyle.FULL
    }

/** The result of [openStage]. */
sealed class OpenStageResult {
    /** Means the Stage is allowed to open. */
    object Allowed : OpenStageResult()

    /** Means the Stage is not allowed to open. */
    object NotAllowed : OpenStageResult()

    /**
     * Failed.
     *
     * @param code Error code
     * @param reason Cause of failure.
     */
    class Error(val code: Int, val reason: String) : OpenStageResult() {
        override fun toString(): String {
            return "Error(code='$code', reason='$reason')"
        }

        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (other !is Error) return false

            if (code.compareTo(other.code) != 0) return false
            if (reason != other.reason) return false

            return true
        }

        override fun hashCode(): Int {
            var result = code
            result = 31 * result + reason.hashCode()
            return result
        }
    }
}

internal fun SpatialContainer.OpenResult.toOpenStageResult(): OpenStageResult {
    return when (this) {
        is SpatialContainer.OpenResult.Failure -> {
            // should give developer a reason, but not now
            OpenStageResult.Error(code = resultCode, reason = "")
        }
        SpatialContainer.OpenResult.Allowed -> OpenStageResult.Allowed
        SpatialContainer.OpenResult.NotAllowed -> OpenStageResult.NotAllowed
    }
}
