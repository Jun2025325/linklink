/*
 * Copyright 2024 - 2026 PICO. All rights reserved.
 *
 * NOTICE: All information contained herein is, and remains the property of PICO.
 * The intellectual and technical concepts contained herein are proprietary to PICO
 * and may be covered by patents, patents in process, and are protected by trade
 * secret or copyright law. Dissemination of this information or reproduction of
 * this material is strictly forbidden unless prior written permission is obtained
 * from PICO.
 */

@file:Suppress("INVISIBLE_MEMBER", "INVISIBLE_REFERENCE")

package com.pico.spatial.ui.platform.containers

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import com.pico.spatial.core.container.SpatialContainerStateObservable
import com.pico.spatial.core.container.Stage
import com.pico.spatial.core.container.StageProperties
import com.pico.spatial.core.platform.SpatialBuild
import com.pico.spatial.ui.platform.ControllerHapticConfiguration
import com.pico.spatial.ui.platform.DefaultStageUpperLimbRenderModelManager
import com.pico.spatial.ui.platform.LocalAudioEffectPlayer
import com.pico.spatial.ui.platform.LocalControllerHapticConfiguration
import com.pico.spatial.ui.platform.LocalHandControllerHaptic
import com.pico.spatial.ui.platform.LocalSpatialAudioEffectConfiguration
import com.pico.spatial.ui.platform.LocalSpatialContainerStateManager
import com.pico.spatial.ui.platform.LocalSpatialContainerStateOwner
import com.pico.spatial.ui.platform.LocalStageImmersionManager
import com.pico.spatial.ui.platform.LocalStageUpperLimbRenderModelManager
import com.pico.spatial.ui.platform.LocalVolumeViewPointManager
import com.pico.spatial.ui.platform.SpatialAudioEffectConfiguration
import com.pico.spatial.ui.platform.SpatialHandControllerHapticImpl
import com.pico.spatial.ui.platform.SpatialViewPointManager
import com.pico.spatial.ui.platform.StageImmersionManagerImpl
import com.pico.spatial.ui.platform.rememberSpatialAudioEffectPlayer

/**
 * A [Stage] implementation to take [Composable] as [content].
 *
 * @param containerId Stage instance id.
 * @param props Stage properties
 * @property content The compose content.
 */
internal class SUIStage(
    containerId: Int,
    props: StageProperties,
    var content: @Composable (StageScope.() -> Unit),
) : Stage(containerId, props) {
    private val stageStateManager: SpatialContainerStateManagerImpl by lazy {
        SpatialContainerStateManagerImpl(this@SUIStage)
    }

    override val stateObservable: SpatialContainerStateObservable by lazy { stageStateManager }

    @Composable
    fun BuildContent(scope: StageScope, viewPointManager: SpatialViewPointManager) {
        val owner = this
        val stateManager = stageStateManager
        val context = LocalContext.current
        val spatialNavigator =
            remember(context) { DefaultSpatialNavigator(context, this.containerId) }
        val spatialContainerParamsUpdater =
            remember(context) { DefaultSpatialContainerParamsUpdater(context) }

        val view = LocalView.current
        val audioEffectPlayer = rememberSpatialAudioEffectPlayer(view, context)

        val spatialStageUpperLimbRenderModelManager =
            remember(context) { DefaultStageUpperLimbRenderModelManager(context) }

        if (SpatialBuild.isSpatialPlatform()) {
            CompositionLocalProvider(
                LocalSpatialContainerStateOwner provides owner,
                LocalSpatialContainerStateManager provides stateManager,
                LocalSpatialNavigator provides spatialNavigator,
                LocalWindowContainerParamsUpdater provides spatialContainerParamsUpdater,
                LocalVolumeViewPointManager provides viewPointManager,
                LocalSpatialContainerInfo provides
                    SpatialContainerInfo(SpatialContainerType.Stage, sp = properties),
                LocalStageImmersionManager provides StageImmersionManagerImpl,
                LocalAudioEffectPlayer provides audioEffectPlayer,
                LocalStageUpperLimbRenderModelManager provides
                    spatialStageUpperLimbRenderModelManager,
                LocalHandControllerHaptic provides SpatialHandControllerHapticImpl(),
                LocalSpatialAudioEffectConfiguration provides
                    SpatialAudioEffectConfiguration.Default,
                LocalControllerHapticConfiguration provides ControllerHapticConfiguration.Default,
            ) {
                scope.content()
            }
        } else {
            CompositionLocalProvider(
                LocalSpatialContainerStateOwner provides owner,
                LocalSpatialContainerStateManager provides stateManager,
                LocalSpatialNavigator provides spatialNavigator,
                LocalWindowContainerParamsUpdater provides spatialContainerParamsUpdater,
                LocalVolumeViewPointManager provides viewPointManager,
                LocalStageImmersionManager provides StageImmersionManagerImpl,
                LocalAudioEffectPlayer provides audioEffectPlayer,
                LocalStageUpperLimbRenderModelManager provides
                    spatialStageUpperLimbRenderModelManager,
            ) {
                scope.content()
            }
        }
    }
}
