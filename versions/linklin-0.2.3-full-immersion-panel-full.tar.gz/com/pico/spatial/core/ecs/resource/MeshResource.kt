/*
 * Copyright 2023 - 2026 PICO. All rights reserved.
 *
 * NOTICE: All information contained herein is, and remains the property of PICO.
 * The intellectual and technical concepts contained herein are proprietary to PICO
 * and may be covered by patents, patents in process, and are protected by trade
 * secret or copyright law. Dissemination of this information or reproduction of
 * this material is strictly forbidden unless prior written permission is obtained
 * from PICO.
 */

package com.pico.spatial.core.ecs.resource

import com.pico.spatial.core.annotation.Keep
import com.pico.spatial.core.ecs.BoundingBox
import com.pico.spatial.core.ecs.LoadType
import com.pico.spatial.core.ecs.animation.Skeleton
import com.pico.spatial.core.ecs.animation.SkeletonJoint
import com.pico.spatial.core.internal.toColor4Adapter
import com.pico.spatial.core.internal.toVector2Adapter
import com.pico.spatial.core.internal.toVector3Adapter
import com.pico.spatial.core.internal.toVector4Adapter
import com.pico.spatial.core.math.Vector3
import com.pico.spatial.core.thread.SpatialDispatchers.runOnScheduleThread
import com.pico.spatial.core.trace.TraceKtx.runWithTraceIfUIThread
import com.pico.spatial.foundation.extensions.exception.ResourceLoadingException as ResourceLoadingExceptionAdapter
import com.pico.spatial.foundation.extensions.spatial.ecs.BoundingBox as BoundingBoxAdapter
import com.pico.spatial.foundation.extensions.spatial.resource.MeshModel as MeshModelAdapter
import com.pico.spatial.foundation.extensions.spatial.resource.MeshResource as MeshResourceAdapter
import java.util.UUID
import kotlin.jvm.Throws

/**
 * A high-level representation of a collection of vertices and edges that define a shape. All models
 * imported into the engine are measured in meters.
 */
@Keep
public class MeshResource internal constructor(meshResourceAdapter: MeshResourceAdapter) :
    Resource(meshResourceAdapter) {

    internal override val adapter: MeshResourceAdapter = meshResourceAdapter

    init {
        resourceMap.put(adapter, this)
    }

    internal constructor() : this(MeshResourceAdapter(0L))

    /**
     * Constructs a mesh resource via file path.
     *
     * @param path The given path.
     * @param loadType The loading type, which determines where to load the mesh resource from. The
     *   default value is `FROM_ASSETS`.
     * @throws ResourceLoadingException If any error occurs during the loading process.
     */
    @Throws(ResourceLoadingException::class)
    public constructor(
        path: String,
        loadType: LoadType = LoadType.FROM_ASSETS,
    ) : this(loadFrom(path, loadType))

    /**
     * Releases this resource when explicit manual ownership is required, such as after [toGlobal].
     */
    override fun close() {
        runOnScheduleThread {
            if (valid) {
                super.close()
            }
        }
    }

    /**
     * Returns whether this mesh has a skeleton (i.e., is a skinned mesh).
     *
     * @return `true` if the mesh has a skeleton; `false` otherwise.
     */
    public fun hasSkeleton(): Boolean {
        return runOnScheduleThread {
            checkValid { "hasSkeleton" }
            return@runOnScheduleThread adapter.hasSkeleton()
        }
    }

    /**
     * Gets the skeleton information.
     *
     * @return The skeleton information of this mesh resource, or null if this mesh has no skeleton
     *   or the skeleton data is unavailable.
     */
    public fun getSkeleton(): Skeleton? {
        return runOnScheduleThread {
            checkValid { "getSkeleton" }
            if (!hasSkeleton()) {
                return@runOnScheduleThread null
            }
            val skeletonAdapter = adapter.getSkeleton() ?: return@runOnScheduleThread null
            val joints =
                skeletonAdapter.joints.map { SkeletonJoint(it.name, it.index, it.parentIndex) }
            val skeleton = Skeleton(joints)
            return@runOnScheduleThread skeleton
        }
    }

    /**
     * Gets the bounding box information of the model.
     *
     * @return The [BoundingBox] data of model.
     */
    @Suppress("MagicNumber")
    public fun getBoundingBox(): BoundingBox {
        return runOnScheduleThread {
            checkValid { "getBoundingBox" }
            val boxArray = adapter.boundingBox
            return@runOnScheduleThread boxArray?.let {
                BoundingBox(Vector3(it[0], it[1], it[2]), Vector3(it[3], it[4], it[5]))
            } ?: BoundingBox.empty
        }
    }

    /**
     * Gets the names of all blend shapes in the mesh.
     *
     * @return An array of strings, each representing the name of a blend shape.
     */
    public fun getBlendShapeNames(): Array<String> {
        return runOnScheduleThread {
            checkValid { "getBlendShapeNames" }
            return@runOnScheduleThread adapter.blendShapeNames
        }
    }

    /**
     * Replaces the geometry of this [MeshResource] with data from a [MeshModel].
     *
     * WARNING:
     * - This method performs blocking I/O. While it can be called on the main thread, on slow
     *   devices or with unstable storage it may cause jank or even ANR.
     * - Prefer invoking this from a background thread or within a coroutine context such as
     *   `withContext(Dispatchers.IO)`.
     *
     * @param model The mesh geometry data.
     * @param bounds Optional bounds for the new geometry.
     * @return `true` if the replacement was applied; `false` otherwise.
     * @throws ResourceLoadingException If the runtime fails to replace the mesh resource.
     */
    @Throws(ResourceLoadingException::class)
    public fun replaceWithMeshModel(model: MeshModel, bounds: BoundingBox? = null): Boolean {
        return runOnScheduleThread {
            checkValid { "replaceWithMeshModel" }
            val adapterModel = model.toAdapter()
            return@runOnScheduleThread try {
                adapter.replaceWithMeshModel(adapterModel, bounds.toBoundingBoxAdapterOrNull())
            } catch (e: ResourceLoadingExceptionAdapter) {
                throw ResourceLoadingException(e)
            }
        }
    }

    /** Factory methods and constants for [MeshResource]. */
    @Keep
    public companion object {

        /**
         * Loads a [MeshResource] via file path.
         *
         * @param path The given path.
         * @param loadType The loading type, which determines where to load the mesh resource from.
         *   The default value is `FROM_ASSETS`.
         * @return The [MeshResource] loaded.
         * @throws ResourceLoadingException If an error occurs during the loading process.
         *
         * Note: For complex or high-resolution resources that require significant processing time,
         * it is strongly recommended to leverage coroutines for loading. This approach prevents
         * blocking the main thread, ensuring a responsive and fluid user experience.
         */
        @JvmStatic
        @Throws(ResourceLoadingException::class)
        public fun load(path: String, loadType: LoadType = LoadType.FROM_ASSETS): MeshResource {
            return MeshResource(loadFrom(path, loadType))
        }

        @JvmStatic
        @Throws(ResourceLoadingException::class)
        private fun loadFrom(
            path: String,
            loadType: LoadType = LoadType.FROM_ASSETS,
        ): MeshResourceAdapter {
            return try {
                runWithTraceIfUIThread("LoadMesh: $path", true) {
                    when (loadType) {
                        LoadType.FROM_ASSETS -> MeshResourceAdapter.loadMeshResourceFromAssets(path)
                        LoadType.FROM_STORAGE ->
                            MeshResourceAdapter.loadMeshResourceFromStorage(path)
                    }
                }
            } catch (e: ResourceLoadingExceptionAdapter) {
                throw ResourceLoadingException(e)
            }
        }

        /**
         * Creates a new [MeshResource] from a [MeshModel].
         *
         * WARNING:
         * - This method performs blocking I/O. While it can be called on the main thread, on slow
         *   devices or with unstable storage it may cause jank or even ANR.
         * - Prefer invoking this from a background thread or within a coroutine context such as
         *   `withContext(Dispatchers.IO)`.
         *
         * @param model The mesh geometry data.
         * @param bounds Optional bounds.
         * @param name The name for the created [MeshResource].
         * @return A new [MeshResource] instance.
         * @throws ResourceLoadingException If the runtime fails to create the mesh resource.
         */
        @JvmStatic
        @Throws(ResourceLoadingException::class)
        public fun createWithMeshModel(
            model: MeshModel,
            bounds: BoundingBox? = null,
            name: String,
        ): MeshResource {
            val adapterModel = model.toAdapter()
            return try {
                MeshResource(
                    MeshResourceAdapter.createWithMeshModel(
                        adapterModel,
                        bounds.toBoundingBoxAdapterOrNull(),
                        name,
                    )
                )
            } catch (e: ResourceLoadingExceptionAdapter) {
                throw ResourceLoadingException(e)
            }
        }

        /**
         * Synchronously creates a plane mesh resource.
         *
         * Bounding Box Specification: The bounding box of the generated plane has a fixed center at
         * the origin {0.0f, 0.0f, 0.0f} (local space). Its half-extents are defined as follows
         * (plane is perpendicular to Z-axis and lies on the X-Y plane):
         * - X-axis half-extent: width / 2.0f (full extent: -width/2 to width/2).
         * - Y-axis half-extent: height / 2.0f (full extent: -height/2 to height/2).
         * - Z-axis half-extent: 0.0f (plane has no thickness along Z-axis).
         *
         * @param width The width of the plane, measured in meters (m). Must be greater than `0`.
         *   Represents the horizontal dimension of the plane in 2D space.
         * @param height The height of the plane, measured in meters (m). Must be greater than `0`.
         *   Represents the vertical dimension of the plane in 2D space.
         * @param cornerRadius (Optional) The radius of the plane's corners, measured in meters (m).
         *   The default value is `0`. If the value is greater than 0, transforms the rectangular
         *   plane into a plane with rounded corners. If the value is less than `0`, it is
         *   considered as `0`. The actual radius used is the minimum of the specified radius and
         *   half the length of the plane's smallest side. This ensures that rounded corners are
         *   properly formed without distorting the plane geometry. However, if the provided radius
         *   does not meet this condition, the runtime calculation will adjust it to ensure the
         *   plane's geometric integrity.
         * @return A [MeshResource] object representing the generated plane. This mesh can be used
         *   in 2D or 3D scenes and simulations where planes of specific sizes and corner styles are
         *   required.
         * @throws ResourceLoadingException If any error occurs during the loading process. That all
         *   `float` parameters are within reasonable ranges:
         *     - All `float` parameters must be positive and represent valid 3D dimensions.
         *     - Extremely small values (approaching 0) may lose their practical significance in 3D
         *       contexts and will be treated as 0 where applicable.
         *     - Excessively large values may lose their geometric or physical significance in 3D
         *       space and may be clamped or adjusted at runtime to maintain the integrity of the
         *       geometry, or may result in an exception being thrown.
         */
        @JvmStatic
        @Throws(ResourceLoadingException::class)
        public fun createPlane(
            width: Float,
            height: Float,
            cornerRadius: Float = 0F,
        ): MeshResource {
            return try {
                MeshResource(MeshResourceAdapter.createPlane(width, height, cornerRadius))
            } catch (e: ResourceLoadingExceptionAdapter) {
                throw ResourceLoadingException(e)
            }
        }

        /**
         * Synchronously creates a sphere mesh resource.
         *
         * Bounding Box Specification: The bounding box of the generated sphere has a fixed center
         * at the origin {0.0f, 0.0f, 0.0f} (local space). Its half-extents are equal to the radius
         * of the sphere in all three axes:
         * - X-axis half-extent: radius (full extent: -radius to radius).
         * - Y-axis half-extent: radius (full extent: -radius to radius).
         * - Z-axis half-extent: radius (full extent: -radius to radius).
         *
         * @param radius The radius of the sphere, measured in meters (m). Must be greater than or
         *   equal to `0`.
         * @return A [MeshResource] object representing the generated sphere.
         * @throws ResourceLoadingException If any error occurs during the loading process. That all
         *   `float` parameters are within reasonable ranges:
         *     - All `float` parameters must be positive and represent valid 3D dimensions.
         *     - Extremely small values (approaching 0) may lose their practical significance in 3D
         *       contexts and will be treated as 0 where applicable.
         *     - Excessively large values may lose their geometric or physical significance in 3D
         *       space and may be clamped or adjusted at runtime to maintain the integrity of the
         *       geometry, or may result in an exception being thrown.
         */
        @JvmStatic
        @Throws(ResourceLoadingException::class)
        public fun createSphere(radius: Float): MeshResource {
            return createSphere(SphereOption(radius).setTopology(PrimitiveSphereTopology.LEGACY))
        }

        /**
         * Synchronously creates a sphere mesh resource from the given [SphereOption].
         *
         * Provides full control over topology and debug name via the chainable [SphereOption].
         *
         * @param option The sphere configuration.
         * @return A [MeshResource] object representing the generated sphere.
         * @throws ResourceLoadingException If any error occurs during the loading process.
         */
        @JvmStatic
        @Throws(ResourceLoadingException::class)
        public fun createSphere(option: SphereOption): MeshResource {
            return try {
                MeshResource(MeshResourceAdapter.createSphere(option.adapter))
            } catch (e: ResourceLoadingExceptionAdapter) {
                throw ResourceLoadingException(e)
            }
        }

        /**
         * Synchronously creates a cylinder mesh resource.
         *
         * Bounding Box Specification: The bounding box of the generated cylinder has a fixed center
         * at the origin {0.0f, 0.0f, 0.0f} (local space). Its half-extents are defined as follows:
         * - X-axis half-extent: equal to radius (full extent: -radius to radius).
         * - Y-axis half-extent: height / 2.0f (full extent: -height/2 to height/2).
         * - Z-axis half-extent: equal to radius (full extent: -radius to radius).
         *
         * @param height The height of the cylinder, measured in meters (m). Must be greater than or
         *   equal to `0`.
         * @param radius The radius of the cylinder, measured in meters (m). Must be greater than or
         *   equal to `0`.
         * @return A [MeshResource] object representing the generated cylinder.
         * @throws ResourceLoadingException If any error occurs during the loading process. That all
         *   `float` parameters are within reasonable ranges:
         *     - All `float` parameters must be positive and represent valid 3D dimensions.
         *     - Extremely small values (approaching 0) may lose their practical significance in 3D
         *       contexts and will be treated as 0 where applicable.
         *     - Excessively large values may lose their geometric or physical significance in 3D
         *       space and may be clamped or adjusted at runtime to maintain the integrity of the
         *       geometry, or may result in an exception being thrown.
         */
        @JvmStatic
        @Throws(ResourceLoadingException::class)
        public fun createCylinder(height: Float, radius: Float): MeshResource {
            return try {
                MeshResource(MeshResourceAdapter.createCylinder(height, radius))
            } catch (e: ResourceLoadingExceptionAdapter) {
                throw ResourceLoadingException(e)
            }
        }

        /**
         * Synchronously creates a cone mesh resource.
         *
         * Bounding Box Specification: The bounding box of the generated cone has a fixed center at
         * the origin {0.0f, 0.0f, 0.0f} (local space). Its half-extents are defined as follows:
         * - X-axis half-extent: equal to radius (full extent: -radius to radius).
         * - Y-axis half-extent: height / 2.0f (full extent: -height/2 to height/2).
         * - Z-axis half-extent: equal to radius (full extent: -radius to radius).
         *
         * @param height The height of the cone, measured in meters (m). Must be greater than or
         *   equal to `0`.
         * @param radius The radius of the cone, measured in meters (m). Must be greater than or
         *   equal to `0`.
         * @return A [MeshResource] object representing the generated cone.
         * @throws ResourceLoadingException If any error occurs during the loading process. That all
         *   `float` parameters are within reasonable ranges:
         *     - All `float` parameters must be positive and represent valid 3D dimensions.
         *     - Extremely small values (approaching 0) may lose their practical significance in 3D
         *       contexts and will be treated as 0 where applicable.
         *     - Excessively large values may lose their geometric or physical significance in 3D
         *       space and may be clamped or adjusted at runtime to maintain the integrity of the
         *       geometry, or may result in an exception being thrown.
         */
        @JvmStatic
        @Throws(ResourceLoadingException::class)
        public fun createCone(height: Float, radius: Float): MeshResource {
            return try {
                MeshResource(MeshResourceAdapter.createCone(height, radius))
            } catch (e: ResourceLoadingExceptionAdapter) {
                throw ResourceLoadingException(e)
            }
        }

        /**
         * Synchronously creates a capsule mesh resource.
         *
         * Bounding Box Specification: The bounding box of the generated capsule has a fixed center
         * at the origin {0.0f, 0.0f, 0.0f} (local space). Its half-extents are defined as follows:
         * - X-axis half-extent: equal to radius (full extent: -radius to radius).
         * - Y-axis half-extent: height / 2.0f + radius (full extent: -height/2 - radius to
         *   height/2 + radius).
         * - Z-axis half-extent: equal to radius (full extent: -radius to radius).
         *
         * @param height The height of the capsule, measured in meters (m). Must be greater than or
         *   equal to `0`.
         * @param radius The radius of the capsule, measured in meters (m). Must be greater than or
         *   equal to `0`.
         * @return A [MeshResource] object representing the generated capsule.
         * @throws ResourceLoadingException If any error occurs during the loading process. That all
         *   `float` parameters are within reasonable ranges:
         *     - All `float` parameters must be positive and represent valid 3D dimensions.
         *     - Extremely small values (approaching 0) may lose their practical significance in 3D
         *       contexts and will be treated as 0 where applicable.
         *     - Excessively large values may lose their geometric or physical significance in 3D
         *       space and may be clamped or adjusted at runtime to maintain the integrity of the
         *       geometry, or may result in an exception being thrown.
         */
        @JvmStatic
        @Throws(ResourceLoadingException::class)
        public fun createCapsule(height: Float, radius: Float): MeshResource {
            return createCapsule(
                CapsuleOption(height, radius).setTopology(PrimitiveCapsuleTopology.LEGACY)
            )
        }

        /**
         * Synchronously creates a capsule mesh resource from the given [CapsuleOption].
         *
         * Provides full control over topology, axis and debug name via the chainable
         * [CapsuleOption].
         *
         * @param option The capsule configuration.
         * @return A [MeshResource] object representing the generated capsule.
         * @throws ResourceLoadingException If any error occurs during the loading process.
         */
        @JvmStatic
        @Throws(ResourceLoadingException::class)
        public fun createCapsule(option: CapsuleOption): MeshResource {
            return try {
                MeshResource(MeshResourceAdapter.createCapsule(option.adapter))
            } catch (e: ResourceLoadingExceptionAdapter) {
                throw ResourceLoadingException(e)
            }
        }

        /**
         * Synchronously creates a box mesh resource.
         *
         * Bounding Box Specification: The bounding box of the generated box has a fixed center at
         * the origin {0.0f, 0.0f, 0.0f} (local space). Its half-extents are defined as follows:
         * - X-axis half-extent: size.x / 2.0f (full extent: -size.x/2 to size.x/2).
         * - Y-axis half-extent: size.y / 2.0f (full extent: -size.y/2 to size.y/2).
         * - Z-axis half-extent: size.z / 2.0f (full extent: -size.z/2 to size.z/2).
         *
         * @param size The size of the box as a [Vector3], measured in meters (m). Each dimension
         *   (x, y, z) respectively represents the length, width, and height of the box. Each
         *   dimension must be greater than 0.
         * @param cornerRadius (Optional) The radius of the box's corners, measured in meters (m).
         *   The default value is `0`. If the radius is greater than `0`, adds rounded corners to
         *   the box, thereby transforming the box into a rounded box. If the radius is specified as
         *   less than `0`, it will be automatically considered as 0, indicating sharp corners. The
         *   actual radius used for the rounded corners is calculated at runtime as the minimum of
         *   the provided radius and half the length of the smallest side of the box. This ensures
         *   that the rounded corners are correctly formed without any geometric distortion,
         *   maintaining the geometric integrity of the shape. If the provided radius does not meet
         *   this condition, the runtime calculation will adjust it to ensure the box's geometric
         *   integrity.
         * @return A [MeshResource] object representing the generated box. This mesh can be used in
         *   3D scenes and simulations where boxes of specific sizes and corner styles are required.
         * @throws ResourceLoadingException If any error occurs during the loading process. That all
         *   `float` parameters are within reasonable ranges:
         *     - All `float` parameters must be positive and represent valid 3D dimensions.
         *     - Extremely small values (approaching 0) may lose their practical significance in 3D
         *       contexts and will be treated as 0 where applicable.
         *     - Excessively large values may lose their geometric or physical significance in 3D
         *       space and may be clamped or adjusted at runtime to maintain the integrity of the
         *       geometry, or may result in an exception being thrown.
         */
        @JvmStatic
        @Throws(ResourceLoadingException::class)
        public fun createBox(size: Vector3, cornerRadius: Float = 0F): MeshResource {
            return createBox(
                BoxOption(size)
                    .setTopology(PrimitiveBoxTopology.LEGACY)
                    .setCornerRadius(cornerRadius)
            )
        }

        /**
         * Synchronously creates a box mesh resource from the given [BoxOption].
         *
         * Provides full control over topology, corner radius, face splitting and debug name via the
         * chainable [BoxOption].
         *
         * @param option The box configuration.
         * @return A [MeshResource] object representing the generated box.
         * @throws ResourceLoadingException If any error occurs during the loading process.
         */
        @JvmStatic
        @Throws(ResourceLoadingException::class)
        public fun createBox(option: BoxOption): MeshResource {
            return try {
                MeshResource(MeshResourceAdapter.createBox(option.adapter))
            } catch (e: ResourceLoadingExceptionAdapter) {
                throw ResourceLoadingException(e)
            }
        }

        /**
         * Synchronously creates a torus mesh resource.
         *
         * Bounding Box Specification: The bounding box of the generated torus has a fixed center at
         * the origin {0.0f, 0.0f, 0.0f} (local space). Its half-extents are defined as follows:
         * - X-axis half-extent: equal to outerRingRadius (full extent: -outerRingRadius to
         *   outerRingRadius)
         * - Y-axis half-extent: (outerRingRadius - innerRingRadius) / 2.0f (full extent:
         *   -(outerRingRadius - innerRingRadius)/2 to (outerRingRadius - innerRingRadius)/2)
         * - Z-axis half-extent: equal to outerRingRadius (full extent: -outerRingRadius to
         *   outerRingRadius)
         *
         * This method creates a torus mesh resource based on the specified outer and inner ring
         * radii. The outer ring radius (`outerRingRadius`) must always be greater than the inner
         * ring radius (`innerRingRadius`), and both radii must be greater than 0. The mesh is
         * generated through a native call that takes these radii as inputs.
         *
         * @param outerRingRadius The radius of the torus's outer ring, measured in meters (m). Must
         *   be greater than `0` and `innerRingRadius`.
         * @param innerRingRadius The radius of the torus's inner ring, measured in meters (m). Must
         *   be greater than `0` and less than `outerRingRadius`.
         * @return A [MeshResource] object representing the generated torus.
         * @throws ResourceLoadingException If any error occurs during the loading process. That all
         *   `float` parameters are within reasonable ranges:
         *     - All `float` parameters must be positive and represent valid 3D dimensions.
         *     - Extremely small values (approaching 0) may lose their practical significance in 3D
         *       contexts and will be treated as 0 where applicable.
         *     - Excessively large values may lose their geometric or physical significance in 3D
         *       space and may be clamped or adjusted at runtime to maintain the integrity of the
         *       geometry, or may result in an exception being thrown.
         */
        @JvmStatic
        @Throws(ResourceLoadingException::class)
        public fun createTorus(outerRingRadius: Float, innerRingRadius: Float): MeshResource {
            return try {
                MeshResource(MeshResourceAdapter.createTorus(outerRingRadius, innerRingRadius))
            } catch (e: ResourceLoadingExceptionAdapter) {
                throw ResourceLoadingException(e)
            }
        }

        /**
         * Creates a mesh resource for a video panel.
         *
         * This function generates a rectangular video panel mesh with the specified width and
         * height, divided into a grid based on the given row and column counts.
         *
         * @param width The width of the panel, measured in meters (m). Must be greater than `0`.
         *   Represents the horizontal dimension of the panel in 2D space.
         * @param height The height of the panel, measured in meters (m). Must be greater than `0`.
         *   Represents the vertical dimension of the panel in 2D space.
         * @param cornerRadius The radius of the panel's corners, measured in meters (m). The
         *   default value is `0`. If the radius is greater than `0`, adds rounded corners to the
         *   box, thereby transforming the box into a rounded box. If the radius is specified as
         *   less than `0`, it will be automatically considered as 0, indicating sharp corners. The
         *   actual radius used for the rounded corners is calculated at runtime as the minimum of
         *   the provided radius and half the length of the smallest side of the box. This ensures
         *   that the rounded corners are correctly formed without any geometric distortion,
         *   maintaining the geometric integrity of the shape. If the provided radius does not meet
         *   this condition, the runtime calculation will adjust it to ensure the box's geometric
         *   integrity.
         * @return A mesh resource representing the created video panel.
         * @throws ResourceLoadingException If an error occurs during the loading process. Ensure
         *   that all `float` parameters are within reasonable ranges:
         *     - All `float` parameters must be positive and represent valid 3D dimensions.
         *     - Extremely small values (approaching 0) may lose their practical significance in 3D
         *       contexts and will be treated as 0 where applicable.
         *     - Excessively large values may lose their geometric or physical significance in 3D
         *       space and may be clamped or adjusted at runtime to maintain the integrity of the
         *       geometry, or may result in an exception being thrown.
         */
        @JvmStatic
        @Throws(ResourceLoadingException::class)
        public fun createVideoPanel(
            width: Float,
            height: Float,
            cornerRadius: Float,
        ): MeshResource {
            return try {
                MeshResource(MeshResourceAdapter.createVideoPanel(width, height, cornerRadius))
            } catch (e: ResourceLoadingExceptionAdapter) {
                throw ResourceLoadingException(e)
            }
        }

        /**
         * Loads mesh resource from mesh anchor.
         *
         * @param anchorUUID The given anchor UUID.
         * @return The loaded [MeshResource].
         * @throws ResourceLoadingException If an error occurs during the loading process.
         */
        @JvmStatic
        @Throws(ResourceLoadingException::class)
        public fun loadFromMeshAnchor(anchorUUID: UUID): MeshResource {
            return try {
                MeshResource(
                    MeshResourceAdapter.loadMeshResourceFromMeshAnchorUUID(anchorUUID.toString())
                )
            } catch (e: ResourceLoadingExceptionAdapter) {
                throw ResourceLoadingException(e)
            }
        }

        /**
         * Loads mesh resource from plane anchor.
         *
         * @param anchorUUID The given anchor UUID.
         * @return The loaded [MeshResource].
         * @throws ResourceLoadingException If an error occurs during the loading process.
         */
        @JvmStatic
        @Throws(ResourceLoadingException::class)
        public fun loadFromPlaneAnchor(anchorUUID: UUID): MeshResource {
            return try {
                MeshResource(
                    MeshResourceAdapter.loadMeshResourceFromPlaneAnchorUUID(anchorUUID.toString())
                )
            } catch (e: ResourceLoadingExceptionAdapter) {
                throw ResourceLoadingException(e)
            }
        }

        private fun MeshModel.toAdapter(): MeshModelAdapter {
            return MeshModelAdapter(
                positions.map { it.toVector3Adapter() },
                triangleIndices,
                normals?.map { it.toVector3Adapter() },
                tangents?.map { it.toVector4Adapter() },
                uv0?.map { it.toVector2Adapter() },
                uv1?.map { it.toVector2Adapter() },
                colors?.map { it.toColor4Adapter() },
            )
        }

        /** Converts [BoundingBox] to its adapter type. */
        private fun BoundingBox.toBoundingBoxAdapter(): BoundingBoxAdapter {
            return BoundingBoxAdapter(center.toVector3Adapter(), halfExtent.toVector3Adapter())
        }

        /** Converts nullable [BoundingBox] to nullable adapter type. */
        private fun BoundingBox?.toBoundingBoxAdapterOrNull(): BoundingBoxAdapter? {
            return this?.toBoundingBoxAdapter()
        }
    }
}
