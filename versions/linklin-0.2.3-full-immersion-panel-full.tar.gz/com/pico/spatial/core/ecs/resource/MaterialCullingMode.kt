/*
 * Copyright 2024 - 2026 PICO. All rights reserved.
 *
 * NOTICE: All information contained herein is, and remains the property of PICO.
 * The intellectual and technical concepts contained herein are proprietary to PICO
 * and may be covered by patents, patents in process, and are protected by trade
 * secret or copyright law. Dissemination of this information or reproduction of
 * this material is strictly forbidden unless prior written permission is obtained
 * from PICO.
 */

package com.pico.spatial.core.ecs.resource

import com.pico.spatial.core.annotation.Keep
import com.pico.spatial.core.internal.Logger

/**
 * Specifies the face culling mode used when rendering a material.
 *
 * Face culling determines which triangle faces are discarded during the rendering pass, optimizing
 * performance by avoiding unnecessary fragment processing. The culling decision is based on the
 * triangle's winding order relative to the camera's viewpoint.
 *
 * Default: [BACK].
 *
 * @property value The integer value of the culling mode.
 */
@Keep
public enum class MaterialCullingMode(@field:Keep public val value: Int) {
    /**
     * Disables face culling.
     *
     * Both front-facing and back-facing triangles are rendered.
     *
     * Pros:
     * - Essential for double-sided materials
     * - Correct for thin geometry where both sides are visible
     *
     * Cons:
     * - Higher fragment processing cost (~2× render cost)
     *
     * Best for: Thin geometry (foliage, cloth, hair, paper), transparent objects, or any materials
     * where both sides should be visible.
     */
    NONE(0),

    /**
     * Culls front-facing triangles.
     *
     * Only back-facing triangles (facing away from the camera) are rendered. Front-facing triangles
     * are culled before rasterization.
     *
     * Best for: Inverse rendering effects, certain volumetric rendering techniques, or debugging
     * winding order issues.
     */
    FRONT(1),

    /**
     * Culls back-facing triangles.
     *
     * Only front-facing triangles (facing toward the camera) are rendered. Back-facing triangles
     * are culled before rasterization.
     *
     * Pros:
     * - Best performance for closed, opaque objects
     * - Standard choice in most rendering engines
     *
     * Best for: Solid, opaque objects (characters, props, buildings). This is the recommended
     * default for most 3D content.
     */
    BACK(2),

    /**
     * Culls both front- and back-facing triangles.
     *
     * No faces are rendered for this material.
     *
     * Best for: Completely hiding the geometry while maintaining its presence in the scene graph,
     * or for objects that only participate in other non-rendering passes.
     */
    FRONT_AND_BACK(3),

    /** Represents a value not recognized by this version of the SDK. */
    UNKNOWN(-1);

    internal companion object {

        fun fromInt(value: Int): MaterialCullingMode {
            return when (value) {
                0 -> NONE
                1 -> FRONT
                2 -> BACK
                3 -> FRONT_AND_BACK
                else -> UNKNOWN
            }
        }

        fun fromValue(value: Int): MaterialCullingMode {
            return when (value) {
                0 -> NONE
                1 -> FRONT
                2 -> BACK
                3 -> FRONT_AND_BACK
                else -> {
                    Logger.w("Unknown MaterialCullingMode value: $value, fallback to UNKNOWN")
                    UNKNOWN
                }
            }
        }
    }
}
