/*
 * Copyright 2023 - 2026 PICO. All rights reserved.
 *
 * NOTICE: All information contained herein is, and remains the property of PICO.
 * The intellectual and technical concepts contained herein are proprietary to PICO
 * and may be covered by patents, patents in process, and are protected by trade
 * secret or copyright law. Dissemination of this information or reproduction of
 * this material is strictly forbidden unless prior written permission is obtained
 * from PICO.
 */

package com.pico.spatial.core.ecs.resource

import com.pico.spatial.core.annotation.Keep
import com.pico.spatial.core.math.Color4
import com.pico.spatial.core.thread.SpatialDispatchers.runOnScheduleThread
import com.pico.spatial.foundation.extensions.exception.ResourceLoadingException as ResourceLoadingExceptionAdapter
import com.pico.spatial.foundation.extensions.spatial.resource.UnlitMaterial as UnlitMaterialAdapter
import kotlin.jvm.Throws

/**
 * A material type that renders without being affected by scene lighting.
 *
 * Material Property Blending:
 *
 * [UnlitMaterial] allows for the blending of different material properties to achieve the desired
 * visual effect. `PropertyValue` and `TextureResource` are combined using a multiplicative blending
 * mode. This means that the final appearance of the material is the result of multiplying the
 * property value with the texture color. This blending mode helps in creating more dynamic and
 * visually interesting effects by combining uniform values and detailed texture information.
 * Allowing for flexible customization and control over the material's appearance. These properties
 * may be represented by different data types, such as linear color and float, to accommodate
 * various material characteristics.
 */
@Keep
public class UnlitMaterial internal constructor(unlitMaterialAdapter: UnlitMaterialAdapter) :
    Material(unlitMaterialAdapter) {

    internal override val adapter: UnlitMaterialAdapter = unlitMaterialAdapter

    /** Strong reference cache to prevent TextureResource from being GC'd. */
    private var baseColorTextureCache: TextureResource? = null

    init {
        resourceMap.put(adapter, this)
    }

    /**
     * Creates an [UnlitMaterial] instance with the specified [BlendingMode].
     *
     * @param blendingMode The [BlendingMode] to use.
     */
    @Throws(ResourceLoadingExceptionAdapter::class)
    private constructor(
        blendingMode: BlendingMode = BlendingMode.OPAQUE
    ) : this(UnlitMaterialAdapter.createUnlitMaterial(blendingMode.value))

    /**
     * Gets the name of the [UnlitMaterial].
     *
     * The name of the [UnlitMaterial] is a read-only property, meaning it can only be retrieved and
     * not modified programmatically. Typically, you can set or change the material's name using the
     * Spatial Editor, allowing for easier identification and management of materials within the
     * development environment.
     *
     * @return The name of the [UnlitMaterial].
     * @throws IllegalStateException If this material is closed or invalid.
     */
    public fun getName(): String {
        return runOnScheduleThread {
            checkValid { "getName" }
            return@runOnScheduleThread adapter.name
        }
    }

    /**
     * Sets the blending mode of the [UnlitMaterial].
     *
     * The blending mode determines how `opacity` and `opacityThreshold` are interpreted:
     * - [BlendingMode.OPAQUE]: `opacity` is ignored.
     * - [BlendingMode.TRANSPARENT] / [BlendingMode.ADD] / [BlendingMode.FADE]: `opacity` controls
     *   how the material blends with the background; `opacityThreshold` is ignored.
     * - [BlendingMode.MASKED]: `opacityThreshold` is used to clip pixels (alpha test) instead of
     *   producing semi-transparent results.
     *
     * @param blendingMode The [BlendingMode] to use.
     * @throws IllegalStateException If this material is closed or invalid.
     * @see BlendingMode
     */
    public fun setBlendingMode(blendingMode: BlendingMode) {
        runOnScheduleThread {
            checkValid { "setBlendingMode" }
            adapter.setBlendingMode(blendingMode.value)
        }
    }

    /**
     * Gets the blending mode of the [UnlitMaterial].
     *
     * @return The [BlendingMode] that the [UnlitMaterial] is using.
     * @throws IllegalStateException If this material is closed or invalid.
     */
    public fun getBlendingMode(): BlendingMode {
        return runOnScheduleThread {
            checkValid { "getBlendingMode" }
            return@runOnScheduleThread BlendingMode.fromValue(adapter.blendingMode)
        }
    }

    /**
     * Sets the [MaterialCullingMode] of the [UnlitMaterial].
     *
     * @param cullingMode The [MaterialCullingMode] to use.
     * @throws IllegalStateException If this material is closed or invalid.
     */
    public fun setCullingMode(cullingMode: MaterialCullingMode) {
        runOnScheduleThread {
            requireValid { "setCullingMode" }
            adapter.cullingMode = cullingMode.value
        }
    }

    /**
     * Gets the [MaterialCullingMode] of the [UnlitMaterial].
     *
     * @return The [MaterialCullingMode] that the [UnlitMaterial] is using.
     * @throws IllegalStateException If this material is closed or invalid.
     */
    public fun getCullingMode(): MaterialCullingMode {
        return runOnScheduleThread {
            requireValid { "getCullingMode" }
            return@runOnScheduleThread MaterialCullingMode.fromValue(adapter.cullingMode)
        }
    }

    /**
     * Sets the fill mode for rendering polygons in the [UnlitMaterial].
     *
     * @param polygonFillMode The fill mode to use. Use [PolygonFillMode.FILL] to keep the default
     *   fill mode.
     * @throws IllegalStateException If this material is closed or invalid.
     */
    public fun setPolygonFillMode(polygonFillMode: PolygonFillMode) {
        runOnScheduleThread {
            requireValid { "setPolygonFillMode" }
            adapter.polygonFillMode = polygonFillMode.value
        }
    }

    /**
     * Gets the fill mode for rendering polygons in the [UnlitMaterial].
     *
     * @return The fill mode that the [UnlitMaterial] is using.
     * @throws IllegalStateException If this material is closed or invalid.
     */
    public fun getPolygonFillMode(): PolygonFillMode {
        return runOnScheduleThread {
            requireValid { "getPolygonFillMode" }
            return@runOnScheduleThread PolygonFillMode.fromValue(adapter.polygonFillMode)
        }
    }

    /**
     * Enables or disables depth testing for the [UnlitMaterial].
     *
     * When depth testing is enabled, the renderer will check the depth buffer to determine if the
     * material should be rendered in front of or behind other objects. Disabling depth testing may
     * result in the material always being rendered on top, regardless of its actual depth in the
     * scene.
     *
     * @param depthTest Whether to enable depth testing. `true`: enable; `false`: disable.
     * @throws IllegalStateException If this material is closed or invalid.
     */
    public fun setDepthTest(depthTest: Boolean) {
        runOnScheduleThread {
            requireValid { "setDepthTest" }
            adapter.depthTest = depthTest
        }
    }

    /**
     * Gets the state of depth testing for the [UnlitMaterial].
     *
     * @return `true` if depth testing is enabled; `false` otherwise.
     * @throws IllegalStateException If this material is closed or invalid.
     */
    public fun getDepthTest(): Boolean {
        return runOnScheduleThread {
            requireValid { "getDepthTest" }
            return@runOnScheduleThread adapter.depthTest
        }
    }

    /**
     * Enables or disables depth writing for the [UnlitMaterial].
     *
     * When depth writing is enabled, the material will update the depth buffer with its depth
     * values.
     *
     * @param depthWrite Whether to enable depth writing. `true`: enable; `false`: disable.
     * @throws IllegalStateException If this material is closed or invalid.
     */
    public fun setDepthWrite(depthWrite: Boolean) {
        runOnScheduleThread {
            requireValid { "setDepthWrite" }
            adapter.depthWrite = depthWrite
        }
    }

    /**
     * Gets the state of depth writing for the [UnlitMaterial].
     *
     * @return `true` if depth writing is enabled; `false` otherwise.
     * @throws IllegalStateException If this material is closed or invalid.
     */
    public fun getDepthWrite(): Boolean {
        return runOnScheduleThread {
            requireValid { "getDepthWrite" }
            return@runOnScheduleThread adapter.depthWrite
        }
    }

    /**
     * Sets the opacity of the [UnlitMaterial].
     *
     * Valid range: `[0.0f, 1.0f]` (inclusive); values outside this range will be clamped to `[0.0f,
     * 1.0f]` when applied.
     *
     * Behavior depends on the current [BlendingMode]:
     * - [BlendingMode.OPAQUE]: ignored, the material is always fully opaque.
     * - [BlendingMode.TRANSPARENT]: `1.0f` is fully opaque, `0.0f` is fully transparent.
     * - [BlendingMode.ADD]: scales the additive contribution; the background remains visible even
     *   at `1.0f`.
     * - [BlendingMode.FADE]: same as [BlendingMode.TRANSPARENT].
     * - [BlendingMode.MASKED]: participates in the alpha test against `opacityThreshold` instead of
     *   producing semi-transparent results.
     *
     * @param opacity The opacity value to set.
     * @throws IllegalStateException If this material is closed or invalid.
     * @see setBlendingMode
     * @see setOpacityThreshold
     */
    public fun setOpacity(opacity: Float) {
        runOnScheduleThread {
            requireValid { "setOpacity" }
            adapter.opacity = opacity
        }
    }

    /**
     * Gets the opacity of the [UnlitMaterial].
     *
     * @return The current opacity value of the [UnlitMaterial].
     * @throws IllegalStateException If this material is closed or invalid.
     */
    public fun getOpacity(): Float {
        return runOnScheduleThread {
            requireValid { "getOpacity" }
            return@runOnScheduleThread adapter.opacity
        }
    }

    /**
     * Sets the opacity threshold of the [UnlitMaterial].
     *
     * Only takes effect when the blending mode is [BlendingMode.MASKED]. Pixels whose alpha is less
     * than this threshold are fully discarded (clipped and not rendered), while pixels with alpha
     * greater than or equal to the threshold are treated as fully opaque. There is no
     * semi-transparent transition under [BlendingMode.MASKED].
     *
     * This value has no effect under other blending modes such as [BlendingMode.OPAQUE],
     * [BlendingMode.TRANSPARENT], [BlendingMode.FADE], or [BlendingMode.ADD].
     *
     * Valid range: `[0.0f, 1.0f]` (inclusive); values outside this range will be clamped to `[0.0f,
     * 1.0f]` when applied. The default value is `0.0f`, which means every pixel passes the alpha
     * test, so the visual result under [BlendingMode.MASKED] is equivalent to
     * [BlendingMode.OPAQUE].
     *
     * @param opacityThreshold The opacity threshold value to set.
     * @throws IllegalStateException If this material is closed or invalid.
     * @see BlendingMode.MASKED
     * @see setOpacity
     */
    public fun setOpacityThreshold(opacityThreshold: Float) {
        runOnScheduleThread {
            requireValid { "setOpacityThreshold" }
            adapter.opacityThreshold = opacityThreshold
        }
    }

    /**
     * Gets the opacity threshold of the [UnlitMaterial].
     *
     * @return The current opacity threshold value of the [UnlitMaterial].
     * @throws IllegalStateException If this material is closed or invalid.
     */
    public fun getOpacityThreshold(): Float {
        return runOnScheduleThread {
            requireValid { "getOpacityThreshold" }
            return@runOnScheduleThread adapter.opacityThreshold
        }
    }

    /**
     * Sets the base color of the [UnlitMaterial].
     *
     * @param color The base color to set.
     * @throws IllegalStateException If this material is closed or invalid.
     */
    public fun setBaseColor(color: Color4) {
        runOnScheduleThread {
            checkValid { "setBaseColor" }
            adapter.setBaseColor(color.red, color.green, color.blue, color.alpha)
        }
    }

    /**
     * Sets the texture to be used as the base color for the [UnlitMaterial].
     *
     * @param texture The texture to set.
     * @throws IllegalStateException If this material or the texture is closed or invalid.
     */
    public fun setBaseColorTexture(texture: TextureResource) {
        runOnScheduleThread {
            checkValid { "setBaseColorTexture" }
            texture.requireValid { "setBaseColorTexture" }
            adapter.baseColorTexture = texture.adapter
            baseColorTextureCache = texture
        }
    }

    /**
     * Gets the base color of the [UnlitMaterial].
     *
     * @return The base color of the [UnlitMaterial].
     * @throws IllegalStateException If this material is closed or invalid.
     */
    public fun getBaseColor(): Color4 {
        return runOnScheduleThread {
            checkValid { "getBaseColor" }
            val value = adapter.baseColor
            return@runOnScheduleThread Color4(value.red, value.green, value.blue, value.alpha)
        }
    }

    /**
     * Gets the base color texture of the [UnlitMaterial].
     *
     * @return The base color texture of the [UnlitMaterial].
     * @throws IllegalStateException If this material is closed or invalid.
     */
    public fun getBaseColorTexture(): TextureResource {
        return runOnScheduleThread {
            checkValid { "getBaseColorTexture" }
            val textureAdapter = adapter.baseColorTexture
            val cached = baseColorTextureCache
            if (cached != null && cached.adapter == textureAdapter) {
                return@runOnScheduleThread cached
            }
            val resource =
                resourceMap.getOrDefault(textureAdapter) { TextureResource(textureAdapter) }
            baseColorTextureCache = resource
            return@runOnScheduleThread resource
        }
    }

    /**
     * Sets whether to apply tone mapping to the [UnlitMaterial].
     *
     * When enabled, the material color is compressed by the scene's tone mapper to map HDR / highly
     * saturated colors into the displayable range, which yields a softer and slightly desaturated
     * look. When disabled, the raw base color is output as-is, which is useful for UI / decal-like
     * content that needs to keep its authored color.
     *
     * @param isApplyToneMapping Whether to apply tone mapping. `true`: apply; `false`: do not
     *   apply.
     * @throws IllegalStateException If this material is closed or invalid.
     */
    public fun setApplyToneMapping(isApplyToneMapping: Boolean) {
        runOnScheduleThread {
            checkValid { "setApplyToneMapping" }
            adapter.isApplyToneMapping = isApplyToneMapping
        }
    }

    /**
     * Gets whether tone mapping is applied to the [UnlitMaterial].
     *
     * @return `true` if tone mapping is applied; `false` otherwise.
     * @throws IllegalStateException If this material is closed or invalid.
     */
    public fun isApplyToneMapping(): Boolean {
        return runOnScheduleThread {
            checkValid { "isApplyToneMapping" }
            return@runOnScheduleThread adapter.isApplyToneMapping
        }
    }

    /** Factory methods and constants for [UnlitMaterial]. */
    @Keep
    public companion object {

        /**
         * Creates a new instance of the [UnlitMaterial] class with the specified [BlendingMode].
         *
         * @param blendingMode The [BlendingMode] to use.
         * @return The [UnlitMaterial] instance created.
         * @throws ResourceLoadingException If any error occurs during the loading process.
         */
        @JvmStatic
        @Throws(ResourceLoadingException::class)
        public fun create(blendingMode: BlendingMode = BlendingMode.OPAQUE): UnlitMaterial {
            return try {
                UnlitMaterial(blendingMode)
            } catch (e: ResourceLoadingExceptionAdapter) {
                throw ResourceLoadingException(e)
            }
        }
    }
}
