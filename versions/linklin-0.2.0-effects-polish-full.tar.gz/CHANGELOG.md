# Changelog

## 0.2.0 — 2026-09-25

Effects polish: **core feedback, Lianliankan path cues, and ambient rhythm**.

### Stage 1 — Core Feel feedback

- Two-card proximity energy link with 18 pulsing star segments.
- Two-card contact star-dust impact.
- Successful pairs converge into a star burst.
- Invalid pairs softly repel while remaining attached for replacement.
- Card-select pop sound.
- Tool hover and click sounds.

### Stage 2 — Lianliankan feedback

- Successful matches draw the actual solver path as a glowing star-dot polyline.
- Hints draw a longer-lived blue guide path.
- Shuffle flights produce colored orbit trails.
- Shuffle plays a whoosh and staggered card-landing sounds.

### Stage 3 — Ambience and rhythm

- Cosmos background slowly rotates.
- Match-success pitch rises with combo streaks.
- Transient floating “连击 ×N” cards appear from combo 2 onward.
- Timed capsule changes from calm blue to warning gold to pulsing coral.
- Win celebration begins with a constellation animation before cannons and fireworks.

### Verification

- `./gradlew testDebugUnitTest assembleDebug` passed.
- SpatialUI design-style verifier passed with 0 errors and 0 warnings.
- Temporary forced 4×4×4 runtime created the board, all 210 gameplay particles, and all 18 energy-link entities without a fatal log.
- Forced startup was removed; the production APK launched in the emulator as process 20501 with `MainStage` visible.
- Real-device effect tuning remains pending headset reconnection.

### Release artifact

- APK: `releases/linklin-0.2.0-effects-polish.apk`

## 0.1.0 — 2026-09-24

Baseline snapshot: **Full-space 3D Lianliankan MVP with two-card-touch Feel mode**.

### Included

- Full-space `DefaultStage` with black cosmos environment.
- Casual, Feel, and Timed Challenge modes.
- 3D animal-card Lianliankan board with 6-direction, up-to-3-turn path matching.
- 3×3×3, 4×4×4, 5×5×5, unlimited custom dimensions, and next-level progression.
- Hints, shuffle, restart, win celebration, timed failure flow, match sounds, and TTS.
- Feel mode: tap-to-stick one card per hand, soft proximity magnetism, and two-card contact matching.
- Draggable initial setup sheet, draggable right-side tool stack, and DirectPinch board translation.
- Gaze/ray board rotation and controller-compatible tap interactions.

### Verification

- `./gradlew testDebugUnitTest assembleDebug` passed.
- SpatialUI design-style verifier passed with 0 errors.
- Emulator launch passed with `MainStage` visible and no fatal app log.
- Real-device validation for the final two-card-contact gesture is pending because the headset was disconnected.

### Release artifact

- APK: `releases/linklin-0.1.0-feel-two-card-touch.apk`
- Full checksummed snapshot: `versions/linklin-0.1.0-feel-two-card-touch-full.tar.gz`
- Snapshot SHA256: `d6eb53afc5977044d8d056c0bc663093132fe176fbf4170fdddd122957dccfb8`
- APK SHA256: `a2ef8377d9e0238dd668d67175f0d439e501fc7eaf019c80cb6a03864bf6a183`
