# Changelog

## 0.1.0 — 2026-09-24

Baseline snapshot: **Full-space 3D Lianliankan MVP with two-card-touch Feel mode**.

### Included

- Full-space `DefaultStage` with black cosmos environment.
- Casual, Feel, and Timed Challenge modes.
- 3D animal-card Lianliankan board with 6-direction, up-to-3-turn path matching.
- 3×3×3, 4×4×4, 5×5×5, unlimited custom dimensions, and next-level progression.
- Hints, shuffle, restart, win celebration, timed failure flow, match sounds, and TTS.
- Feel mode: tap-to-stick one card per hand, soft proximity magnetism, and two-card contact matching.
- Draggable initial setup sheet, draggable right-side tool stack, and DirectPinch board translation.
- Gaze/ray board rotation and controller-compatible tap interactions.

### Verification

- `./gradlew testDebugUnitTest assembleDebug` passed.
- SpatialUI design-style verifier passed with 0 errors.
- Emulator launch passed with `MainStage` visible and no fatal app log.
- Real-device validation for the final two-card-contact gesture is pending because the headset was disconnected.

### Release artifact

- APK: `releases/linklin-0.1.0-feel-two-card-touch.apk`
